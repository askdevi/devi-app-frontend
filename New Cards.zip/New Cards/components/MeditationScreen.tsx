import React from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity, Platform } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';

export default function MeditationScreen() {
  return (
    <View style={styles.contentContainer}>
      <View style={styles.inputContainer}>
        <View style={styles.phoneInputContainer}>
          <View style={styles.countryCode}>
            <Text style={styles.countryCodeText}>+91</Text>
          </View>
          <TextInput
            style={styles.input}
            placeholder="Enter phone number"
            placeholderTextColor="rgba(255, 215, 0, 0.5)"
            keyboardType="phone-pad"
          />
        </View>
        
        <TouchableOpacity activeOpacity={0.8}>
          <LinearGradient
            colors={['#D4AF37', '#FFD700']}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 0 }}
            style={styles.button}
          >
            <Text style={styles.buttonText}>Send OTP</Text>
            <Text style={styles.arrowIcon}>→</Text>
          </LinearGradient>
        </TouchableOpacity>
        
        <View style={styles.termsContainer}>
          <Text style={styles.termsText}>
            By continuing, you agree to our{' '}
            <Text style={styles.termsLink}>Terms</Text> and{' '}
            <Text style={styles.termsLink}>Privacy Policy</Text>
          </Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  contentContainer: {
    width: '100%',
    padding: 20,
    marginTop: 30,
  },
  inputContainer: {
    width: '100%',
    marginTop: 20,
  },
  phoneInputContainer: {
    flexDirection: 'row',
    width: '100%',
    height: 60,
    borderRadius: 12,
    backgroundColor: 'rgba(71, 35, 122, 0.5)',
    marginBottom: 20,
    borderWidth: 1,
    borderColor: 'rgba(255, 215, 0, 0.3)',
    overflow: 'hidden',
  },
  countryCode: {
    width: 80,
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
    borderRightWidth: 1,
    borderColor: 'rgba(255, 215, 0, 0.3)',
  },
  countryCodeText: {
    color: '#FFD700',
    fontSize: 18,
    fontWeight: '500',
  },
  input: {
    flex: 1,
    height: '100%',
    paddingHorizontal: 15,
    color: '#FFD700',
    fontSize: 18,
  },
  button: {
    width: '100%',
    height: 60,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
    flexDirection: 'row',
  },
  buttonText: {
    color: '#2a1450',
    fontSize: 18,
    fontWeight: 'bold',
  },
  arrowIcon: {
    color: '#2a1450',
    fontSize: 18,
    fontWeight: 'bold',
    marginLeft: 10,
  },
  termsContainer: {
    alignItems: 'center',
    marginTop: 15,
  },
  termsText: {
    color: 'rgba(255, 255, 255, 0.7)',
    fontSize: 14,
    textAlign: 'center',
  },
  termsLink: {
    color: '#FFD700',
    textDecorationLine: 'underline',
  },
});