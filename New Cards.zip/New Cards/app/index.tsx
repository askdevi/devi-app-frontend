import { View, Text, StyleSheet, Image, Platform, Pressable, Dimensions } from 'react-native';
import { useRouter } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { StatusBar } from 'expo-status-bar';
import Svg, { Defs, RadialGradient, Stop, Circle } from 'react-native-svg';
import OrbitingStars from '../components/OrbitingStars';
import RippleRings from '../components/RippleRings';
import BackgroundStars from '../components/BackgroundStars';

const GLOW_RADIUS = 120; // Matches the logo container size

export default function SplashScreen() {
  const router = useRouter();
  
  const GlowEffect = () => {
    return (
      <View style={styles.glowContainer}>
        <Svg height="100%" width="100%" style={StyleSheet.absoluteFill}>
          <Defs>
            <RadialGradient
              id="glow"
              cx="50%"
              cy="50%"
              r="50%"
              fx="50%"
              fy="50%"
              gradientUnits="userSpaceOnUse"
            >
              <Stop offset="0" stopColor="#FFD700" stopOpacity="0.4" />
              <Stop offset="0.4" stopColor="#FFD700" stopOpacity="0.2" />
              <Stop offset="0.7" stopColor="#FFD700" stopOpacity="0.05" />
              <Stop offset="1" stopColor="#FFD700" stopOpacity="0" />
            </RadialGradient>
          </Defs>
          <Circle
            cx="120"
            cy="120"
            r={GLOW_RADIUS}
            fill="url(#glow)"
          />
        </Svg>
      </View>
    );
  };

  return (
    <Pressable style={styles.container} onPress={() => router.push('/loading')}>
      <StatusBar style="light" />
      <LinearGradient
        colors={['#0a0219', '#1a0632', '#0a0219']}
        style={styles.background}
        start={{ x: 0.5, y: 0 }}
        end={{ x: 0.5, y: 1 }}
      />
      
      <BackgroundStars count={30} />
      
      <View style={styles.content}>
        <View style={styles.logoContainer}>
          <RippleRings />
          <GlowEffect />
          <Image 
            source={require('../assets/images/logo.png')} 
            style={styles.logo}
            resizeMode="contain"
          />
          <OrbitingStars />
        </View>

        <Text style={styles.title}>Ask Devi</Text>
        <Text style={styles.subtitle}>Your Personal Vedic Astrologer</Text>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    position: 'relative',
    overflow: 'hidden',
  },
  background: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
  },
  content: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 20,
  },
  logoContainer: {
    width: 240,
    height: 240,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 40,
    borderRadius: 120,
    overflow: 'hidden',
  },
  glowContainer: {
    position: 'absolute',
    width: '100%',
    height: '100%',
    overflow: 'hidden',
    borderRadius: 120,
  },
  logo: {
    width: 220,
    height: 220,
    position: 'absolute',
    zIndex: 10,
  },
  title: {
    fontSize: 42,
    fontWeight: 'bold',
    textAlign: 'center',
    includeFontPadding: false,
    color: '#FFD700',
    textShadowColor: 'rgba(255, 215, 0, 0.6)',
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 10,
  },
  subtitle: {
    fontSize: 18,
    color: '#FFD700',
    opacity: 0.8,
    textAlign: 'center',
    marginTop: 8,
  },
});