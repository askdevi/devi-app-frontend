import React, { useState } from 'react';
import { View, Text, StyleSheet, Pressable, Dimensions, Platform } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { ChevronLeft, ChevronRight } from 'lucide-react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withTiming,
  interpolate,
  Extrapolate,
} from 'react-native-reanimated';
import BackgroundStars from '../../components/BackgroundStars';

const { width: SCREEN_WIDTH } = Dimensions.get('window');

const CARDS = [
  {
    id: 'mantra',
    title: 'Lucky Mantra',
    value: 'Om Gam Ganapataye Namaha',
  },
  {
    id: 'color',
    title: 'Lucky Color',
    value: 'Deep Purple',
  },
  {
    id: 'number',
    title: 'Lucky Number',
    value: '108',
  },
  {
    id: 'time',
    title: 'Auspicious Time',
    value: 'Sunrise (5:42 AM - 6:30 AM)',
  },
];

function BlessingCard({ 
  card, 
  index, 
  activeIndex, 
  flipped,
  onFlip 
}: { 
  card: typeof CARDS[0],
  index: number,
  activeIndex: number,
  flipped: boolean,
  onFlip: () => void
}) {
  const position = index - activeIndex;
  const isActive = position === 0;
  
  const rotate = useSharedValue(flipped ? 180 : 0);
  const translateX = useSharedValue(position * (SCREEN_WIDTH * 0.8));
  const scale = useSharedValue(isActive ? 1 : 0.8);
  const opacity = useSharedValue(isActive ? 1 : 0.5);

  React.useEffect(() => {
    rotate.value = withTiming(flipped ? 180 : 0, { duration: 800 });
    translateX.value = withTiming(position * (SCREEN_WIDTH * 0.8), { duration: 500 });
    scale.value = withTiming(isActive ? 1 : 0.8, { duration: 500 });
    opacity.value = withTiming(isActive ? 1 : 0.5, { duration: 500 });
  }, [flipped, position, isActive]);

  const frontStyle = useAnimatedStyle(() => ({
    transform: [
      { translateX: translateX.value },
      { scale: scale.value },
      { rotateY: `${interpolate(rotate.value, [0, 180], [0, 180])}deg` },
    ],
    opacity: opacity.value,
    backfaceVisibility: 'hidden',
  }));

  const backStyle = useAnimatedStyle(() => ({
    transform: [
      { translateX: translateX.value },
      { scale: scale.value },
      { rotateY: `${interpolate(rotate.value, [0, 180], [180, 360])}deg` },
    ],
    opacity: opacity.value,
    backfaceVisibility: 'hidden',
  }));

  const CardPattern = () => (
    <View style={styles.pattern}>
      {Array.from({ length: 10 }).map((_, i) => (
        <View
          key={i}
          style={[
            styles.patternLine,
            {
              transform: [{ rotate: `${i * 18}deg` }],
              opacity: 0.1 + (i * 0.05),
            },
          ]}
        />
      ))}
    </View>
  );

  return (
    <>
      <Animated.View style={[styles.card, frontStyle]}>
        <Pressable
          style={styles.cardInner}
          onPress={isActive ? onFlip : undefined}
        >
          <LinearGradient
            colors={['#FFD700', '#FDB931', '#FFD700']}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={StyleSheet.absoluteFill}
          />
          <CardPattern />
          <Text style={styles.cardTitle}>{card.title}</Text>
          <Text style={styles.tapText}>Tap to reveal</Text>
        </Pressable>
      </Animated.View>

      <Animated.View style={[styles.card, styles.cardBack, backStyle]}>
        <Pressable
          style={styles.cardInner}
          onPress={isActive ? onFlip : undefined}
        >
          <LinearGradient
            colors={['#581189', '#360059']}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={StyleSheet.absoluteFill}
          />
          <Text style={styles.cardValue}>{card.value}</Text>
        </Pressable>
      </Animated.View>
    </>
  );
}

export default function BlessingsScreen() {
  const [activeIndex, setActiveIndex] = useState(0);
  const [flippedCards, setFlippedCards] = useState<Record<string, boolean>>({});

  const navigateCards = (direction: 'left' | 'right') => {
    const newIndex = direction === 'left' 
      ? Math.max(0, activeIndex - 1)
      : Math.min(CARDS.length - 1, activeIndex + 1);
    setActiveIndex(newIndex);
  };

  const toggleFlip = (cardId: string) => {
    setFlippedCards(prev => ({
      ...prev,
      [cardId]: !prev[cardId],
    }));
  };

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={['#360059', '#1D0033', '#0D0019']}
        style={StyleSheet.absoluteFill}
      />
      
      <BackgroundStars count={30} />

      <View style={styles.header}>
        <Text style={styles.title}>Your Daily Blessings</Text>
        <Text style={styles.subtitle}>Swipe and tap to reveal your destiny</Text>
      </View>

      <View style={styles.carouselContainer}>
        {CARDS.map((card, index) => (
          <BlessingCard
            key={card.id}
            card={card}
            index={index}
            activeIndex={activeIndex}
            flipped={flippedCards[card.id] || false}
            onFlip={() => toggleFlip(card.id)}
          />
        ))}

        <View style={styles.navigationButtons}>
          <Pressable
            style={[styles.navButton, activeIndex === 0 && styles.navButtonDisabled]}
            onPress={() => navigateCards('left')}
            disabled={activeIndex === 0}
          >
            <ChevronLeft color="#FFD700" size={32} />
          </Pressable>
          
          <Pressable
            style={[styles.navButton, activeIndex === CARDS.length - 1 && styles.navButtonDisabled]}
            onPress={() => navigateCards('right')}
            disabled={activeIndex === CARDS.length - 1}
          >
            <ChevronRight color="#FFD700" size={32} />
          </Pressable>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#360059',
  },
  header: {
    paddingTop: Platform.OS === 'ios' ? 60 : 40,
    paddingHorizontal: 20,
    alignItems: 'center',
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#FFD700',
    textAlign: 'center',
    textShadowColor: 'rgba(255, 215, 0, 0.5)',
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 10,
  },
  subtitle: {
    fontSize: 16,
    color: '#FFD700',
    opacity: 0.8,
    marginTop: 8,
    textAlign: 'center',
  },
  carouselContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  card: {
    position: 'absolute',
    width: SCREEN_WIDTH * 0.8,
    height: 400,
    borderRadius: 20,
    elevation: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
  },
  cardBack: {
    position: 'absolute',
  },
  cardInner: {
    flex: 1,
    borderRadius: 20,
    padding: 20,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(255, 215, 0, 0.3)',
  },
  pattern: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
  },
  patternLine: {
    position: 'absolute',
    width: '200%',
    height: 1,
    backgroundColor: '#FFD700',
    top: '50%',
    left: '-50%',
  },
  cardTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#360059',
    textAlign: 'center',
    marginTop: 40,
  },
  cardValue: {
    fontSize: 24,
    fontWeight: '600',
    color: '#FFD700',
    textAlign: 'center',
    marginTop: 40,
  },
  tapText: {
    position: 'absolute',
    bottom: 30,
    left: 0,
    right: 0,
    textAlign: 'center',
    color: '#360059',
    opacity: 0.7,
    fontSize: 16,
  },
  navigationButtons: {
    position: 'absolute',
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: SCREEN_WIDTH,
    paddingHorizontal: 20,
  },
  navButton: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: 'rgba(88, 17, 137, 0.3)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255, 215, 0, 0.3)',
  },
  navButtonDisabled: {
    opacity: 0.3,
  },
});