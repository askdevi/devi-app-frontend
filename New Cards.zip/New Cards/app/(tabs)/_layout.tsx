import { Tabs } from 'expo-router';
import { Gift } from 'lucide-react-native';

export default function TabLayout() {
  return (
    <Tabs 
      screenOptions={{ 
        headerShown: false,
        tabBarStyle: { display: 'none' }
      }}
      initialRouteName="blessings"
    >
      <Tabs.Screen 
        name="index" 
        options={{
          href: null
        }}
      />
      <Tabs.Screen
        name="chat"
        options={{
          href: null
        }}
      />
      <Tabs.Screen 
        name="blessings"
        options={{
          title: 'Blessings',
          tabBarIcon: ({ color, size }) => <Gift color={color} size={size} />
        }}
      />
    </Tabs>
  );
}