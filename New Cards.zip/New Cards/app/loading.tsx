import React from 'react';
import { View, Text, StyleSheet, Image, Platform, Pressable, Dimensions } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { StatusBar } from 'expo-status-bar';
import { useRouter } from 'expo-router';
import Svg, { Defs, RadialGradient, Stop, Circle } from 'react-native-svg';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withRepeat,
  withDelay,
  withTiming,
  Easing,
} from 'react-native-reanimated';

const { width, height } = Dimensions.get('window');
const GLOW_RADIUS = 140; // Adjusted to match container size
const FLOWER_COUNT = 12;

function FlowerRing() {
  const flowers = Array.from({ length: FLOWER_COUNT }, (_, i) => {
    const angle = (i / FLOWER_COUNT) * 2 * Math.PI;
    const delay = i * (6000 / FLOWER_COUNT);
    return { angle, delay };
  });

  return (
    <View style={styles.flowerContainer}>
      {flowers.map((flower, index) => (
        <AnimatedFlower
          key={index}
          angle={flower.angle}
          delay={flower.delay}
        />
      ))}
    </View>
  );
}

function AnimatedFlower({ angle, delay }: { angle: number; delay: number }) {
  const glow = useSharedValue(0);
  const radius = 120;
  const x = Math.cos(angle) * radius;
  const y = Math.sin(angle) * radius;

  React.useEffect(() => {
    glow.value = withDelay(
      delay,
      withRepeat(
        withTiming(1, { 
          duration: 2000,
          easing: Easing.inOut(Easing.ease) 
        }),
        -1,
        true
      )
    );
  }, []);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ translateX: x }, { translateY: y }],
    opacity: glow.value,
  }));

  return (
    <Animated.Text
      style={[
        styles.flower,
        animatedStyle,
      ]}
    >
      ꕥ
    </Animated.Text>
  );
}

const GlowEffect = () => {
  return (
    <View style={styles.glowContainer}>
      <Svg height="100%" width="100%" style={StyleSheet.absoluteFill}>
        <Defs>
          <RadialGradient
            id="glow"
            cx="50%"
            cy="50%"
            r="50%"
            fx="50%"
            fy="50%"
            gradientUnits="userSpaceOnUse"
          >
            <Stop offset="0" stopColor="#FFD700" stopOpacity="0.4" />
            <Stop offset="0.4" stopColor="#FFD700" stopOpacity="0.2" />
            <Stop offset="0.7" stopColor="#FFD700" stopOpacity="0.05" />
            <Stop offset="1" stopColor="#FFD700" stopOpacity="0" />
          </RadialGradient>
        </Defs>
        <Circle
          cx="140"
          cy="140"
          r={GLOW_RADIUS}
          fill="url(#glow)"
        />
      </Svg>
    </View>
  );
};

export default function LoadingScreen() {
  const router = useRouter();

  return (
    <Pressable style={styles.container} onPress={() => router.push('/(tabs)/chat')}>
      <StatusBar style="light" />
      <LinearGradient
        colors={['#0a0219', '#1a0632', '#0a0219']}
        style={styles.background}
        start={{ x: 0.5, y: 0 }}
        end={{ x: 0.5, y: 1 }}
      />
      
      <View style={styles.content}>
        <View style={styles.headerContainer}>
          <Text style={styles.namaste}>Namaste</Text>
          <Text style={styles.loadingText}>Loading Your Personal Vedic Astrologer</Text>
        </View>
        
        <View style={styles.imageContainer}>
          <GlowEffect />
          <FlowerRing />
          <Image 
            source={require('../assets/images/welcome.png')} 
            style={styles.welcomeImage}
            resizeMode="contain"
          />
        </View>

        <Text style={styles.quote}>
          The universe speaks in the language of stars
        </Text>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    position: 'relative',
  },
  background: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
  },
  content: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 60,
    paddingHorizontal: 20,
  },
  headerContainer: {
    alignItems: 'center',
    marginTop: 20,
  },
  namaste: {
    fontSize: 36,
    fontWeight: 'bold',
    color: '#FFD700',
    textShadowColor: 'rgba(255, 215, 0, 0.6)',
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 15,
    marginBottom: 8,
  },
  loadingText: {
    fontSize: 16,
    color: '#FFD700',
    opacity: 0.8,
    textAlign: 'center',
  },
  imageContainer: {
    width: 280,
    height: 280,
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
    borderRadius: 140,
    overflow: 'hidden',
  },
  glowContainer: {
    position: 'absolute',
    width: '100%',
    height: '100%',
    overflow: 'hidden',
    borderRadius: 140,
  },
  welcomeImage: {
    width: 200,
    height: 200,
    position: 'relative',
    zIndex: 10,
  },
  flowerContainer: {
    position: 'absolute',
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
  },
  flower: {
    position: 'absolute',
    fontSize: 24,
    color: '#FFD700',
    textShadowColor: 'rgba(255, 215, 0, 0.8)',
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 10,
  },
  quote: {
    fontSize: 14,
    color: 'rgba(255, 255, 255, 0.7)',
    fontStyle: 'italic',
    textAlign: 'center',
  },
});